# LinguaStream

**Creador:** Alex Daniel  
**Licencia:** AGPL-3.0  
**Estado:** Proyecto educativo libre y gratuito

---

## ✨ Qué es LinguaStream

**LinguaStream** es una aplicación gratuita y abierta que permite aprender idiomas mientras ves contenido audiovisual (anime, series, películas, streams), mostrando en pantalla:

- Subtítulos en tu idioma nativo (ej. español)
- Subtítulos originales (ej. japonés, inglés, etc.)
- Transcripción fonética del idioma original (ej. romaji, pinyin, etc.)

Todo sincronizado, en tiempo real y desde cualquier dispositivo.

---

## 📆 Propósito

Empoderar a las personas para aprender idiomas de forma divertida, accesible y gratuita mientras disfrutan del contenido que aman.

---

## 🛠 Tecnologías previstas

- App móvil (Flutter o React Native)
- Versión web (HTML5 + JavaScript)
- Extensión para navegadores (opcional)
- Subtítulos en formatos .srt, .ass compatibles
- Conversión automática a transcripción fonética

---

## 🌎 Visión

Una herramienta libre y global, creada por y para la comunidad, que respete el aprendizaje, el acceso gratuito y el respeto por los contenidos.

---

## 💪 Contribuciones

Todos pueden colaborar. Este proyecto es comunitario, y cualquier persona que quiera sumar:

- Código (frontend/backend)
- Traducciones y fonética
- Diseño UX/UI
- Difusión

... es bienvenida. Se valora la transparencia y el respeto al enfoque gratuito y educativo.

---

## 🔒 Licencia

Este proyecto está licenciado bajo **GNU Affero General Public License v3.0**.  
Esto asegura que cualquier copia o versión modificada **tambien debe ser gratuita y abierta**, y que **el autor original (Alex Daniel) sea reconocido en todo momento**.

---

## ✨ Contacto y comunidad

En construcción. Se planifica crear:

- Grupo de Telegram o Discord para desarrollo
- Sitio web oficial con roadmap y colaboraciones
- Espacio de donaciones voluntarias (Ko-fi / Patreon)

---

**LinguaStream** nace con una sola meta:  
“Que aprender idiomas sea tan fácil y libre como mirar una serie o una película.”
